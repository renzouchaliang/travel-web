import { useState } from "react";
import type { Day, RestaurantGroup, Trip } from "../../types/travel";
import { mapLabel } from "../../maps/labels";
import { ExternalLinks } from "./ExternalLinks";
export function sortedCandidates(
  group: RestaurantGroup,
  trip: Trip,
  platform = "",
) {
  return [...group.candidates].sort((a, b) => {
    if (platform) {
      const ar = trip.places[a.placeId].rating,
        br = trip.places[b.placeId].rating;
      const av = ar?.platform === platform ? ar.value / ar.scale : undefined,
        bv = br?.platform === platform ? br.value / br.scale : undefined;
      return av === undefined
        ? bv === undefined
          ? 0
          : 1
        : bv === undefined
          ? -1
          : bv - av;
    }
    // Distances of different kinds/origins are not silently compared.
    const ad = a.distance,
      bd = b.distance;
    if (!ad) return bd ? 1 : 0;
    if (!bd) return -1;
    return ad.kind === bd.kind && ad.originPlaceId === bd.originPlaceId
      ? ad.meters - bd.meters
      : 0;
  });
}
export function RestaurantRow({
  trip,
  candidate,
  onMap,
}: {
  trip: Trip;
  candidate: RestaurantGroup["candidates"][number];
  onMap: () => void;
}) {
  const p = trip.places[candidate.placeId],
    d = candidate.distance;
  const restaurantLinks = p.links.some((l) => l.platform === "美团") ? p.links : [...p.links, {
    id: `${p.id}-meituan-search`, platform: "美团", action: "search" as const,
    label: "美团搜索", targetType: "search" as const,
    url: `https://www.meituan.com/s/${encodeURIComponent([p.providerIds?.amapCity, p.name, p.branchName].filter(Boolean).join(" "))}/`,
  }];
  const priority = (link: typeof restaurantLinks[number]) => link.platform === "大众点评" ? 0 : link.platform === "美团" ? 1 : link.action === "location" ? 2 : 3;
  const orderedLinks = [...restaurantLinks].sort((a, b) => priority(a) - priority(b));
  const title = mapLabel(p);
  return (
    <article className="restaurant-row">
      <h4>{title}</h4>
      <p>
        {p.foodTags?.join(" / ")} · {p.address ?? p.areaId ?? "区域暂无"}
      </p>
      {d && <p>{d.kind === "straight" ? "直线约" : d.kind === "walking" ? "步行约" : "驾车约"}{d.meters < 1000 ? `${Math.round(d.meters)}米` : `${(d.meters / 1000).toFixed(1)}公里`}</p>}
      {p.rating && <p>{p.rating.platform} {p.rating.value}/{p.rating.scale}</p>}
      <div className="card-actions"><ExternalLinks links={orderedLinks} maxVisible={4} platformLabels />{p.coordinate && <button className="compact-map-button" onClick={onMap}>在地图看</button>}</div>

    </article>
  );
}
export function RestaurantList({
  trip,
  day,
  onMap,
}: {
  trip: Trip;
  day: Day;
  onMap: (id: string) => void;
}) {
  const [activeGroups, setActiveGroups] = useState<Record<string, string>>({});
  const active = day.restaurantGroups.find((g) => g.id === activeGroups[day.id]) ?? day.restaurantGroups[0];
  const choose = (id: string) => setActiveGroups((v) => ({ ...v, [day.id]: id }));
  return <section id="dining"><h2>沿途吃什么</h2>
    <div className="dining-tabs" role="tablist" aria-label="附近餐饮区域">{day.restaurantGroups.map((g, i) => <button key={g.id} id={`dining-tab-${day.id}-${g.id}`} role="tab" aria-selected={active?.id === g.id} aria-controls={`dining-panel-${day.id}`} tabIndex={active?.id === g.id ? 0 : -1} onClick={() => choose(g.id)} onKeyDown={(e) => {
      let next = i;
      if (e.key === "ArrowRight") next = (i + 1) % day.restaurantGroups.length;
      else if (e.key === "ArrowLeft") next = (i + day.restaurantGroups.length - 1) % day.restaurantGroups.length;
      else if (e.key === "Home") next = 0;
      else if (e.key === "End") next = day.restaurantGroups.length - 1;
      else return;
      e.preventDefault(); choose(day.restaurantGroups[next].id); document.getElementById(`dining-tab-${day.id}-${day.restaurantGroups[next].id}`)?.focus();
    }}>{g.title}</button>)}</div>
    {active && <section className="travel-card restaurant-group" id={`dining-panel-${day.id}`} role="tabpanel" aria-labelledby={`dining-tab-${day.id}-${active.id}`}><p>{active.description}</p>{active.candidates.map((c) => <RestaurantRow key={c.placeId} trip={trip} candidate={c} onMap={() => onMap(c.placeId)} />)}</section>}
  </section>;
}
